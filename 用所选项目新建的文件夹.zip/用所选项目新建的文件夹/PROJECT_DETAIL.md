# 7zrpw_cj — 7z 压缩包密码恢复工具 (仓颉移植版)

## 项目简介

* [ ]

**运行方式**: 纯命令行模式，`cjpm run -- <文件路径>`，也适合脚本调用和右键菜单集成。

---

## 项目结构

```
7zrpw_cj/
├── cjpm.toml                 # 仓颉项目管理配置 (cjpm)
├── cjpm.lock                 # 依赖锁文件
├── passwd.txt                # 密码字典文件 (一行一个密码)
├── PROJECT_DETAIL.md         # 本说明文件
├── src/
│   ├── main.cj               # 程序入口、命令行参数解析、主流程编排
│   ├── archive_type.cj        # 压缩包枚举定义、类型检测、分卷处理
│   ├── cracker.cj             # 7z 进程调用、密码测试、破解循环、解压
│   ├── password_file.cj       # 密码文件读写、字符串修剪、密码去重
│   └── utils.cj               # 文件大小格式化、耗时格式化、解压路径生成
└── target/release/bin/main    # 编译产物 (执行 cjpm build 后生成)
```

---

## 源码统计


| 文件               | 行数 | 职责                                       |
| ------------------ | ---- | ------------------------------------------ |
| `main.cj`          | 175  | 入口、CLI 参数解析、主流程、手动密码输入   |
| `archive_type.cj`  | 144  | 枚举定义、类型检测、分卷路径处理、类型描述 |
| `cracker.cj`       | 139  | 7z 进程调用、密码逐个验证、破解循环、解压  |
| `password_file.cj` | 121  | 密码文件读取、字符串 trim、多文件去重合并  |
| `utils.cj`         | 125  | 文件大小/耗时格式化、解压目录名生成        |
| **总计**           | 704  |                                            |

### 模块依赖关系

```
main.cj
  ├── archive_type.cj   (detectArchiveType, isPasswordRequired, getFirstVolumePath, getTypeDescription)
  ├── cracker.cj        (crackArchive, testPassword, extractArchive)
  ├── password_file.cj  (getAllPasswords, trimSpace)
  └── utils.cj          (formatFileSize, formatDuration, getDefaultExtractPath)

archive_type.cj
  └── (独立模块，仅依赖 std.fs.*)

cracker.cj
  └── (独立模块，依赖 7z 系统命令)

password_file.cj
  └── (独立模块，依赖 std.fs.* 和 std.io.*)

utils.cj
  └── (独立模块，仅依赖 std.fs.*)
```

---

## 支持的文件格式


| 格式 | 扩展名 | 分卷格式                        | 说明             |
| ---- | ------ | ------------------------------- | ---------------- |
| ZIP  | `.zip` | `.zip.001`, `.zip.002`, ...     | 最常见的压缩格式 |
| RAR  | `.rar` | `.part1.rar`, `.part2.rar`, ... | WinRAR 压缩格式  |
| 7Z   | `.7z`  | `.7z.001`, `.7z.002`, ...       | 7-Zip 原生格式   |

**注意**: 所有格式均默认需要密码。如果压缩包无密码，程序会在破解循环开始时优先尝试空密码。

---

## 核心功能

### 1. 命令行模式（唯一运行方式）

```bash
cjpm run -- <压缩文件路径>
```

- 直接指定文件路径，程序自动检测文件类型并开始破解
- 支持相对路径和绝对路径
- 处理完成后提示"按回车键退出"，避免窗口一闪而过
- 无参数运行时显示用法帮助

### 2. 密码破解流程

```
启动 → 打印 Banner → 检查 passwd.txt 是否存在（不存在则创建空文件）
→ 检测压缩包类型 → 获取解压路径 → 定位第一个分卷（如为分卷格式）
→ 读取密码字典 → 先去重 → 优先尝试空密码
→ 逐一测试密码 → 实时显示进度
→ 找到密码 → 自动解压
→ 未找到密码 → 进入手动输入模式
```

**进度显示格式**:

```
正在尝试密码... 42/100 (42.0%) [password123]
```

**破解速度统计**:

```
破解用时: 3秒 (平均 33.0 密码/秒)
```

### 3. 密码测试原理

对每个密码调用 `7z t` 命令（测试模式，不解压），检查输出中是否包含 `"Everything is Ok"` 字符串来判断密码是否正确。错误识别条件包括：

- `"Cannot open encrypted archive"` — 无法打开加密压缩包
- `"Data Error in encrypted file"` — 加密文件数据错误
- `"ERROR:"` — 通用错误
- `"Wrong password"` — 密码错误
- `"Archives with Errors"` — 压缩包有错误
- 进程退出码非 0

### 4. 自动解压

密码正确后自动调用 `7z x` 命令解压到以压缩包名命名的目录：

- `test.zip` → 解压到 `test/`
- `archive.7z` → 解压到 `archive/`
- `file.part1.rar` → 解压到 `file/`
- 分卷文件自动定位到第一个分卷后解压

解压前自动创建目标目录（`recursive: true`）。

### 5. 手动输入密码

当字典中所有密码均不匹配时：

- 程序提示"密码破解失败！"
- 进入交互式密码输入循环
- 输入正确密码后自动解压，并将密码追加保存到 `passwd.txt`
- 输入错误密码提示"密码错误！请重试或回车退出"
- 直接回车退出

### 6. 密码管理

- **读取路径**: 当前工作目录的 `passwd.txt`，以及程序可执行文件所在目录的 `passwd.txt`
- **文件格式**: 每行一个密码，自动去除首尾空白，空行自动跳过
- **去重**: 使用 `HashSet` 对多个文件合并后的密码去重
- **自动保存**: 手动输入的正确密码自动追加到当前目录的 `passwd.txt`

---

## 仓颉语言特性运用


| 特性                            | 所在文件             | 使用场景                             |
| ------------------------------- | -------------------- | ------------------------------------ |
| `enum`                          | archive_type.cj      | 定义`ArchiveType` 枚举               |
| `match` 模式匹配                | 多处                 | 类型判断、Option 解构、字符匹配      |
| `Option<T>`                     | 多处                 | 文件打开、密码查找、路径解析等可空值 |
| `ArrayList<T>`                  | 多处                 | 密码列表、文件列表、命令行参数       |
| `HashSet<T>`                    | password_file.cj     | 密码去重                             |
| `HashMap<K,V>`                  | password_file.cj     | 密码文件路径到行数映射               |
| `StringReader`                  | password_file.cj     | 密码文件逐行读取                     |
| `String.toRuneArray()`          | 多处                 | Unicode 字符级字符串处理             |
| `toAsciiLower()`                | archive_type.cj      | 扩展名不区分大小写比较               |
| `std.process.executeWithOutput` | cracker.cj           | 调用 7z 外部进程                     |
| `std.fs.File / FileInfo / Path` | 多处                 | 文件系统操作                         |
| `std.fs.Directory`              | cracker.cj / main.cj | 创建目录 / 确保文件存在              |
| `std.time.MonoTime`             | cracker.cj           | 精确计时                             |
| `std.env.getWorkingDirectory`   | password_file.cj     | 获取当前目录 / 可执行文件目录        |
| `std.env.getCommandLine`        | main.cj              | 读取命令行参数                       |
| `std.io.getStdIn`               | main.cj              | 读取用户键盘输入                     |
| 元组`(T1, T2, ...)`             | password_file.cj     | getAllPasswords 多返回值             |
| `for-in` 循环                   | 多处                 | 集合遍历                             |
| 字符串插值`"${var}"`            | 多处                 | 输出格式化                           |
| `                               |                      | `/`&&` 逻辑运算符                    |

---

## 与原 Go 版本的差异


| 功能             | Go 版本        | 仓颉移植版   | 备注                  |
| ---------------- | -------------- | ------------ | --------------------- |
| 密码破解         | 支持           | 支持         | 核心功能完整移植      |
| 解压缩           | 支持           | 支持         | 核心功能完整移植      |
| 分卷支持         | 支持           | 支持         | ZIP/RAR/7Z 分卷       |
| 命令行模式       | 支持           | 支持         | `cjpm run -- <path>`  |
| 交互模式         | 支持           | 不支持       | 已移除，专注命令行    |
| 右键菜单集成     | Windows 注册表 | 适合脚本调用 | 命令行模式天然支持    |
| 剪贴板粘贴       | Windows API    | 不支持       | 平台相关功能          |
| 内嵌 7z 二进制   | `//go:embed`   | 依赖系统`7z` | 需手动安装 p7zip      |
| 自动更新         | 支持           | 不支持       | 非核心功能            |
| JWT 密码上报     | 支持           | 不支持       | 服务端功能            |
| GBK 编码处理     | 支持           | 不支持       | Windows 中文编码      |
| 多文件批量处理   | 支持           | 不支持       | 每次处理一个文件      |
| 更多压缩格式     | 14 种          | 3 种核心格式 | 仅 ZIP / RAR / 7Z     |
| 密码保存         | 支持           | 支持         | 自动追加到 passwd.txt |
| 密码去重         | 支持           | 支持         | HashSet 实现          |
| 空密码优先测试   | 支持           | 支持         | 减少无效尝试          |
| 分卷路径自动处理 | 支持           | 支持         | 自动定位第一个分卷    |

---

## 各源码文件详细说明

### main.cj (175 行)

**程序入口和主流程编排**。

```cj
main(): Int64
```

- 读取命令行参数 `getCommandLine()`
- 打印 Banner 横幅
- 确保当前目录 `passwd.txt` 文件存在（不存在则创建空文件）
- 如果有命令行参数：检测文件类型，处理压缩文件，调用 `waitEnter()` 等待退出
- 如果无参数：显示用法帮助后退出

```cj
func processArchiveFile(archivePath: String)
```

主处理流程：

1. [ ]  显示文件大小和类型
2. [ ]  计算解压目标路径
3. [ ]  处理分卷（自动定位第一个分卷）
4. [ ]  无需密码则直接解压
5. [ ]  加载密码字典
6. [ ]  调用 `crackArchive` 破解
7. [ ]  破解失败则调用 `handleManualPassword`

```cj
func handleManualPassword(archivePath: String, extractPath: String)
```

手动密码输入循环：

- 提示用户输入密码
- 用 `testPassword` 验证
- 正确则解压并 `savePassword` 保存
- 错误则提示重试
- 空行退出

```cj
func savePassword(password: String)
```

追加新密码到当前目录的 `passwd.txt` 文件。

其他辅助函数：

- `isArchiveSupported()` — 判断 `ArchiveType` 是否为已知类型
- `printBanner()` — 打印欢迎横幅
- `getAbsolutePath()` — 将路径字符串包装为 Path 对象
- `waitEnter()` — 暂停等待用户按键

---

### archive_type.cj (144 行)

**压缩包类型枚举、检测、分卷处理和描述**。

```cj
enum ArchiveType {
    Zip | Rar | SevenZip
    | ZipPart | RarPart | SevenZipPart
    | Unknown
}
```

7 个变体：3 种常规格式 + 3 种分卷格式 + 1 个未知兜底。

```cj
func detectArchiveType(path: String): ArchiveType
```

检测流程：

1. **先检查分卷**: 文件名包含 `.7z.` → SevenZipPart；包含 `.zip.` → ZipPart；包含 `.part` 且以 `.rar` 结尾 → RarPart
2. **再检查扩展名**: `.zip` → Zip；`.rar` → Rar；`.7z` → SevenZip
3. **兜底**: 返回 Unknown

```cj
func isPasswordRequired(fileType: ArchiveType): Bool
```

使用 `match` 模式匹配，所有已知格式都需要密码，仅 `Unknown` 返回 false。

```cj
func getFirstVolumePath(archivePath: String): String
```

分卷路径处理逻辑：

- **7Z 分卷**: `file.7z.003` → 找到最后一个 `.7z.` 位置，替换为 `.7z.001`
- **ZIP 分卷**: `file.zip.003` → 类似处理，替换为 `.zip.001`，并检查文件是否存在
- **RAR 分卷**: `file.part3.rar` → 找到最后一个 `.part` 位置，替换为 `.part1.rar`

```cj
func getTypeDescription(fileType: ArchiveType): String
```

返回中文描述，如 `"ZIP 压缩文件"`、`"7Z 分卷压缩文件"` 等。

```cj
func removeAfterLast(s: String, marker: String): String
```

Rune 级别的字符串截取函数。查找 marker 在字符串中最后出现的位置，返回 marker 之前的部分。找不到则返回原字符串。

辅助函数：

- `buildPath()` — 拼接父目录路径和子文件名
- `fileExists()` — 检查路径是否存在且为普通文件

---

### cracker.cj (139 行)

**7z 进程调用、密码验证、破解循环和解压**。

```cj
func getSevenZipPath(): String
```

返回硬编码的 `"7z"`（依赖系统 PATH 中有 `7z` 命令）。

```cj
func formatPasswordArg(password: String): String
```

格式化密码参数：

- 空密码返回 `-p`
- 无特殊字符返回 `-p<password>`
- 含空格/引号/反斜杠时进行转义，使用双引号包裹：`-p"<escaped>"`

```cj
func testPassword(archivePath: String, password: String): Bool
```

核心密码验证逻辑：

1. 构造命令 `7z t <password_arg> <archive>`
2. 执行 `executeWithOutput` 获取标准输出和标准错误
3. 合并 stdout + stderr 检查结果
4. `"Everything is Ok"` → 密码正确
5. 错误关键字匹配 → 密码错误
6. 其他情况以退出码为准

```cj
func crackArchive(archivePath: String, passwords: ArrayList<String>): Option<String>
```

破解循环：

1. 记录开始时间（`MonoTime.now()`）
2. **优先尝试空密码**
3. 遍历密码列表，逐个调用 `testPassword`
4. 显示实时进度（调用 `formatProgress`）
5. 找到密码后打印速度统计，返回 `Some(password)`
6. 全部失败打印统计，返回 `None`

```cj
func formatProgress(current, total: Int64, currentPass: String): String
```

格式化进度条：`\r正在尝试密码... 42/100 (42.0%) [password123]`，使用 `\r` 覆盖同一行。

```cj
func extractArchive(archivePath: String, password: String, extractPath: String): Bool
```

解压逻辑：

1. 确保解压目录存在（`Directory.create` with `recursive: true`）
2. 构造命令 `7z x -y <password_arg> -o<extractPath> <archive>`
3. 记录解压耗时
4. 返回 `exitCode == 0` 表示是否成功

---

### password_file.cj (121 行)

**密码文件读写、字符串处理、密码合并去重**。

```cj
func readPasswordFile(path: String): ArrayList<String>
```

逐行读取密码文件：

1. 调用 `tryOpenFile` 尝试打开
2. 使用 `StringReader` 逐行读取
3. 每行 `trimSpace` 去除空白，跳过空行
4. 关闭文件，返回密码列表

```cj
func trimSpace(s: String): String
```

Rune 级别的字符串首尾空白去除，识别空格、Tab、CR、LF 四种空白字符。

```cj
func isSpace(ch: Rune): Bool
```

判断单个字符是否为空白。

```cj
func tryOpenFile(path: String): Option<File>
```

安全的文件打开函数：先检查文件是否存在且为普通文件，是则返回 `Some(File)`，否则返回 `None`。

```cj
func getAllPasswords(exeDir: String): (ArrayList<String>, String)
```

获取所有可用密码（核心函数）：

1. 收集两个路径：当前目录的 `passwd.txt`、可执行文件目录的 `passwd.txt`
2. 如果两个路径相同，只读取一次
3. 使用 `HashSet` 合并去重
4. 使用 `HashMap` 记录每个文件的密码数量
5. 返回去重后的密码列表和信息摘要字符串

**信息摘要示例输出**:

```
使用的密码文件:
1. /Users/xxx/passwd.txt (包含 500 个密码)
2. /home/7zrpw/passwd.txt (包含 200 个密码)

去重后共 650 个密码
```

---

### utils.cj (125 行)

**格式化工具和路径处理**。

```cj
func formatFileSize(size: Int64): String
```

递归除以 1024，找到合适的单位（B/KB/MB/GB/TB...），输出格式如 `"1.5 MB"`。

```cj
func formatDuration(seconds: Int64): String
```

秒数格式化：

- ≥ 3600 秒: `"X时XX分XX秒"`
- ≥ 60 秒: `"XX分XX秒"`
- < 60 秒: `"X秒"`
- 分秒位补零

```cj
func getDefaultExtractPath(archivePath: String): String
```

生成解压目录名：

1. 获取文件名
2. 去掉最后一个 `.` 后的扩展名
3. 去掉可能的压缩格式扩展名（`.7z` / `.zip` / `.rar`）
4. 去掉 `.partN` 分卷编号
5. 拼接父目录路径

示例转换：

- `test.zip` → `test/`
- `archive.rar` → `archive/`
- `bigfile.7z.003` → `bigfile/`
- `data.part2.rar` → `data/`

辅助函数：

- `charAt()` — 安全获取字符串指定位置字符
- `padZero()` — 数字补零
- `stripSuffix()` — 去掉字符串末尾 N 个字符

---

## 使用前提

**必须安装 p7zip**，确保 `7z` 命令可用：

```bash
# macOS
brew install p7zip

# Ubuntu / Debian
sudo apt install p7zip-full

# 验证安装
7z --help
```

---

## 快速开始

```bash
# 1. 进入项目目录
cd 7zrpw_cj

# 2. 创建密码字典（一行一个密码）
echo "123456" > passwd.txt
echo "password" >> passwd.txt
echo "abc123" >> passwd.txt

# 3. 运行（指定压缩文件路径）
cjpm run -- test.zip

# 或使用绝对路径
cjpm run -- /path/to/archive.rar

# 也可处理分卷文件（自动定位第一个分卷）
cjpm run -- archive.part3.rar

# 编译为独立可执行文件
cjpm build
```

---

## 开发环境


| 项目       | 版本/工具                |
| ---------- | ------------------------ |
| 仓颉工具链 | 1.0.5                    |
| 包管理器   | cjpm                     |
| 平台       | macOS / Linux            |
| 编译命令   | `cjpm build`             |
| 运行命令   | `cjpm run -- <文件路径>` |
| 外部依赖   | p7zip (`7z` 命令)        |
| 编程语言   | 仓颉 (Cangjie)           |

---

## 适用场景

- 忘记压缩包密码，手头有一份常用密码字典
- 需要批量测试密码字典的有效性
- 通过脚本/右键菜单批量处理加密压缩包（命令行模式天然适配）
- 学习仓颉语言的实践项目
