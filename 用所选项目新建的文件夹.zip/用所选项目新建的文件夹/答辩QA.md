# 7zrpw_cj 答辩 Q&A 预测

---

## 一、项目概述类

### Q1: 这个项目是做什么的？为什么要做这个项目？

* [ ]

选择这个项目的理由：

- 功能闭环完整：输入→处理→输出，适合展示语言工程能力
- 涉及多种仓颉特性：enum、match、Option、集合类型、外部进程调用、文件 I/O、Unicode 字符串处理
- 原 Go 版代码结构清晰，便于做语言对比分析

### Q2: 整体架构是怎样的？

**答**: 5 个模块，675 行代码，按职责分层：

```
main.cj (入口/编排)
  ├── archive_type.cj (类型枚举+检测)
  ├── cracker.cj      (7z 进程调用+密码验证)
  ├── password_file.cj(密码字典读写+去重)
  └── utils.cj        (格式化+路径处理)
```

main.cj 只做流程编排，具体逻辑委托给各模块。这是单一职责原则的应用。

### Q3: 支持哪些压缩格式？为什么只支持这几种？

**答**: 支持 ZIP、RAR、7Z 及其分卷格式，共 6 种。原 Go 版支持 14 种格式（GZ、TAR、ISO 等），但移植版聚焦三种最常用的加密压缩格式。这些格式共享同一套 `7z` 命令行接口（`7z t` 测试密码 + `7z x` 解压），代码可以统一处理，架构更简洁。

---

## 二、语言特性类

### Q4: `enum ArchiveType` 的设计思路？和 Go 的枚举有什么不同？

**答**: 仓颉的 `enum` 是代数数据类型（ADT），类似 Rust 的枚举，每个变体可以携带数据：

```cj
enum ArchiveType {
    Zip | Rar | SevenZip
    | ZipPart | RarPart | SevenZipPart
    | Unknown
}
```

对比 Go 的枚举（`iota` 常量），仓颉枚举的优势：

- 编译器检查穷举性：`match` 时必须覆盖所有变体或提供 `_` 兜底
- 自文档化：变体名直接表达语义，不需要注释
- 类型安全：不能用整数替代枚举值

### Q5: `match` 模式匹配在项目中怎么用的？比 if-else 好在哪里？

**答**: 项目中 5 个文件都用了 `match`，三种典型场景：

**场景 1: 枚举穷举**（archive_type.cj 第 113 行）

```cj
match (fileType) {
    case ArchiveType.Zip => "ZIP 压缩文件"
    case ArchiveType.Rar => "RAR 压缩文件"
    ...
    case _ => "未知文件类型"   // 必须兜底
}
```

编译器强制覆盖所有变体，漏写一个就编译不过。

**场景 2: Option 解构**（main.cj 第 115 行、password_file.cj 第 12 行）

```cj
match (foundPassword) {
    case None => handleManualPassword(...)
    case Some(password) => extractArchive(...)
}
```

不需要 `if err != nil` 的 Go 风格，语言层面保证空安全。

**场景 3: 整数匹配**（main.cj 的 `parseInt`）

```cj
match (ch) {
    case '0' => result = result * 10 + 0
    case '1' => result = result * 10 + 1
    ...
}
```

优于 if-else 的地方：编译器检查穷举性、代码更紧凑、可读性更强。

### Q6: `Option<T>` 和 Go 的多返回值 + `nil` 有什么区别？

**答**: 仓颉用 `Option<T>` 表达"可能没有值"的语义，有两处关键对比：

**Go 的方式**（原版）:

```go
func crackArchive(path string, passwords []string) (string, bool) {
    // ...
    return "", false  // 没找到
    return password, true  // 找到了
}
```

问题：调用方可能忘记检查 bool 返回值。

**仓颉的方式**（移植版 cracker.cj 第 75 行）:

```cj
func crackArchive(...): Option<String> {
    return None           // 没找到
    return Some(password) // 找到了
}
```

优势：调用方**必须**用 `match` 解构才能取值，编译器保证不会忘记处理 `None` 的情况。这是类型系统提供的安全保证。

### Q7: 字符串处理为什么要用 `toRuneArray()`？直接用 String 不行吗？

**答**: 因为仓颉的 String 是 UTF-8 编码，直接用索引 `s[i]` 是按字节访问，遇到中文等多字节字符会出错。`toRuneArray()` 将字符串转为 Unicode 码点数组（Rune = Unicode scalar value），之后按索引访问就是按字符。

举例：密码文件中的路径可能包含中文（macOS 上很常见），文件名也可能是中文，所以必须用 Rune 级处理才能保证正确。

项目中集中体现在 `substringTo`（utils.cj 第 105 行）、`trimSpace`（password_file.cj 第 28 行）、`stripSuffix` 等函数。

### Q8: `HashSet` 和 `HashMap` 用在什么地方？为什么要用它们？

**答**: 都在 `password_file.cj` 的 `getAllPasswords` 函数中：

```cj
var passwordSet = HashSet<String>()    // 密码去重
var fileCounts = HashMap<String, Int64>()  // 文件→密码数映射
```

- `HashSet`：程序可能读取两个 `passwd.txt`（当前目录 + 程序目录），密码可能重复。用 `HashSet` 做 O(1) 去重，比数组遍历 O(n²) 高效得多。
- `HashMap`：记录每个文件贡献了多少密码，用于显示"使用的密码文件"摘要。

这也是 Go 的 `map[string]struct{}` + `map[string]int` 在仓颉中的直接对应。

---

## 三、进程交互类

### Q9: 怎么调用外部 `7z` 命令的？为什么不直接解压？

**答**: 使用 `std.process.executeWithOutput`（cracker.cj 第 51 行）：

```cj
let (exitCode, stdOut, stdErr) = executeWithOutput("7z", args.toArray())
```

分两步走的设计：

1. **测试密码**: `7z t -p<password> <archive>` — `t` 模式只测试不解压，速度快
2. **正式解压**: `7z x -y -p<password> -o<output> <archive>` — 密码正确后才解压

这样设计的好处：如果 1000 个密码只有 1 个正确，前 999 个都只做轻量测试，不需要重复解压。

### Q10: 怎么判断密码是否正确？判断逻辑可靠吗？

**答**: 四级判断（cracker.cj `testPassword` 第 57-69 行）：

1. 合并 stdout + stderr，检查 `"Everything is Ok"` → 密码正确（7z 标准成功输出）
2. 检查 5 种错误关键字 → 密码错误
3. 都不匹配时，以 `exitCode == 0` 兜底

为什么不是简单检查 exitCode？

- 7z 在某些错误场景（如密码错误）也会返回 exitCode 2，不是简单的 0/非0
- `"Everything is Ok"` 是 7z 权威的成功标识
- 多层判断比单一条件更健壮

### Q11: 密码参数为什么要做转义处理？

**答**: 如果密码包含空格、引号或反斜杠（比如 `my password`、`p@ss"word`），直接拼接到命令行会造成 shell 解析错误。

`formatPasswordArg`（cracker.cj 第 14 行）的处理逻辑：

- 空密码 → `-p`（不带参数值）
- 无特殊字符 → `-p123456`
- 含特殊字符 → 转义后用双引号包裹：`-p"my\ \"password"`

用单轮遍历同时完成转义和引号判断，比原版两轮遍历更高效。

---

## 四、错误处理类

### Q12: 仓颉版有错误处理吗？和 Go 的 `if err != nil` 有什么异同？

**答**: 仓颉版没有沿用 Go 的显式错误返回模式，而是采用以下策略：


| 场景         | 处理方式                              | 所在位置                         |
| ------------ | ------------------------------------- | -------------------------------- |
| 文件不存在   | FileInfo 提前检查 → println + return | main.cj 第 25-35 行              |
| 文件打开失败 | `Option<File>` + match                | password_file.cj 的`tryOpenFile` |
| 密码未找到   | `Option<String>` → match None 分支   | main.cj 第 115-117 行            |
| 7z 进程失败  | exitCode 检查 + 输出关键字匹配        | cracker.cj 第 57-69 行           |

对比 Go：仓颉的 `Option<T>` + `match` 模式比 Go 的 `if err != nil` 更结构化——编译器强制你处理 None 情况，不会漏掉错误路径。

### Q13: 如果 `passwd.txt` 不存在会怎样？如果密码字典为空呢？

**答**: 代码在第 16-18 行处理了这个边界情况：

```cj
if (!passwdInfo.isRegular()) {
    File.create(Path(passwdPath))   // 自动创建空文件
}
```

如果密码字典为空（getAllPasswords 返回空列表），程序仍可使用手动输入密码功能（main.cj 第 136-165 行），不会崩溃。

---

## 五、设计权衡类

### Q14: 为什么去掉了交互模式？原 Go 版是有的。

**答**: 这是一个有意的设计决策：

- **命令行模式更通用**：适合脚本、右键菜单、CI 流水线等自动化场景
- **职责单一**：程序只做一件事——接收路径，破解解压，不承担文件浏览器的角色
- **仓颉标准库限制**：交互模式需要 `std.io.getStdIn` 配合目录扫描，代码量 ~100 行但增加了测试和 UI 逻辑的复杂度

这反而体现了移植的价值：不是照搬，而是根据目标语言的生态做合理裁剪。

### Q15: 为什么不把颜色输出、进度条、GUI 也移植过来？

**答**: 遵循**最小可用优先**原则：

- 核心路径（检测→破解→解压→保存密码）完整移植
- 进度显示只保留 `\r` 覆盖行（cracker.cj 第 113 行），不做颜色/动画
- 非核心功能明确标注"未移植"（PROJECT_DETAIL.md 对比表），展示工程判断能力

### Q16: 为什么模块要拆成 5 个文件？合并成一个不是更简单吗？

**答**: 按**编译单元内聚**原则拆分：

- `archive_type.cj`：类型定义 + 判断逻辑，可独立测试
- `cracker.cj`：外部进程交互，隔离了系统依赖
- `password_file.cj`：文件 I/O + 数据处理
- `utils.cj`：纯函数工具，无副作用
- `main.cj`：只做编排，不包含业务逻辑

好处：每个模块职责单一、可独立理解和修改、依赖方向清晰（main → 各模块，模块间最大化解耦）。

---

## 六、移植挑战类

### Q17: 移植过程中遇到的最大困难是什么？

**答**: 两个主要困难：

**1. 字符串处理的差异**

Go 的字符串按字节处理（`s[i]` 是 byte），中文平台容易乱码。仓颉的 String 是 UTF-8 但通过 `toRuneArray()` 提供 Unicode 码点级操作。项目中所有字符串截取（`substringTo`、`stripSuffix`、`removeAfterLast`）都基于 Rune 实现，保证中英文混排场景的正确性。

**2. 外部进程调用的参数拼接**

Go 版直接用 `exec.Command` 的 variadic args，仓颉需要通过 `ArrayList<String>` 收集参数再 `toArray()`。密码中的特殊字符（空格、引号）需要手动转义，写 `formatPasswordArg` 时做了单轮遍历优化。

### Q18: 仓颉标准库和 Go 标准库相比有什么差距？

**答**: 几个实际遇到的对比：


| 需求         | Go 标准库                    | 仓颉标准库                     | 影响       |
| ------------ | ---------------------------- | ------------------------------ | ---------- |
| 子串查找     | `strings.Index`              | `lastIndexOf` + `contains`     | 够用       |
| 子串截取     | `s[start:end]` (切片语法)    | 需手动`toRuneArray` 后遍历拼接 | 更冗长     |
| 外部进程     | `exec.Command`               | `executeWithOutput`            | 功能相当   |
| HashSet      | 无内置（用`map[T]struct{}`） | 有`HashSet<T>`                 | 仓颉更直观 |
| StringReader | `bufio.Scanner`              | `StringReader` + `lines()`     | 相当       |

最大的不方便是没有 `s[start..end]` 切片语法，需要手动实现 Rune 级子串截取。项目中抽取了 `substringTo` 复用来解决这个问题。

### Q19: 这个项目让你对仓颉语言有什么认识？

**答**:

- **强项**: `enum` + `match` 的模式匹配非常强大，比 Go 的 switch + type assertion 安全得多；`Option<T>` 让空值处理更规范
- **弱项**: 标准库不如 Go 成熟，特别是字符串操作缺少便捷方法；编译后需要 libcangjie-runtime 动态库，不能像 Go 那样生成独立静态二进制
- **整体感受**: 仓颉的安全性和表达力优于 Go，生态成熟度还有成长空间

---

## 七、安全与边界类

### Q20: 程序有安全漏洞吗？比如命令注入？

**答**: 密码参数经过了转义处理（`formatPasswordArg`），包含空格/引号/反斜杠的密码会被正确转义。文件路径通过 `Path` 类型构造，不直接拼接到 shell 命令。

但有个已知限制：7z 的 `-o` 输出路径参数没有做转义处理（cracker.cj 第 125 行用 `-o${extractPath}` 直接拼接）。如果路径包含特殊字符可能有风险。不过解压路径是从文件名自动生成的，而文件名一般不会有高危字符，实际风险较低。这是在项目文档中标注的一个改进方向。

### Q21: 如果需要扩展到支持更多格式，应该怎么改？

**答**: 扩展非常直观——只需改动 `archive_type.cj`：

1. 在 `ArchiveType` 枚举中新增变体（如 `Gz | Tar | Iso`）
2. 在 `detectArchiveType` 中添加对应的扩展名检测
3. `isPasswordRequired`、`getTypeDescription` 中补充新变体的 match 分支——编译器会提醒所有遗漏的 match 分支

因为核心的 `7z` 命令本身就支持这些格式，`cracker.cj` 完全不用改。这证明了模块化设计的扩展性。

---

## 八、总结陈述模板

用于 1 分钟项目概述：

> 7zrpw_cj 是一个从 Go 移植到仓颉的压缩包密码恢复工具，675 行代码，5 个模块。用户通过命令行指定加密压缩文件，程序自动读取密码字典，调用 7z 命令逐个尝试，找到密码后自动解压。
>
> 项目中重点运用了仓颉语言的 enum 代数数据类型、match 模式匹配、Option 空安全、HashSet/HashMap 集合、Rune 级 Unicode 字符串处理、以及外部进程交互。相比原 Go 版本，仓颉的类型系统提供了更强的编译期安全保障。
>
> 在架构上遵循单一职责原则，5 个模块各司其职，同时抽取了 `substringTo` 等公共函数消除重复代码。项目经历了交互模式移除、命令行参数语法修正、代码冗余优化等迭代，最终代码精简到 675 行。
